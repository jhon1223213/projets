
package JuegoCraps;

/**
 * Class Dado genera un valor Ramdon entre 1 y 6
 * @author Jhon Frank Vasquez - jhon.frank.vasquez@correounivalle.edu.co - 2226510
 * @author Juan Felipe Palechor - juanfelipepalechor@gmail.com - 2270963
 * @version v.1.0.0 16/05/23
 */


import java.util.Random;

public class Dado {

    private int cara;

    /**
     * Metodo que genera un valor ramdom aleatorio
     * @return # entre (1,6)
     */
    public int getCara() {
        Random aleatorio =new Random();
        cara = aleatorio.nextInt()+1;
        return cara;
    }

    public void setCara(int cara) {
        if (cara >= 1 && cara <= 6) {
            this.cara = cara;
        }
    }

}


