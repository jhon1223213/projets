package JuegoCraps;
import java.util.Random;

/**
 * Clase ACCION DE LAS CARAS
 * @author Jhon Frank Vasquez - jhon.frank.vasquez@correounivalle.edu.co - 2226510
 * @author Juan Felipe Palechor - juanfelipepalechor@gmail.com - 2270963
 * @version v.1.0.0 16/05/23
 */
public class Cara {

    private int valor;

    private boolean numerica;
    private int meeple ;
    private int naveEspacial ;
    private boolean superheroe ;
    private boolean corazon ;
    private boolean dragon ;

    public Cara(int valor, int meeple, int naveEspacial, boolean superheroe, boolean corazon, boolean dragon, boolean numerica) {
        this.valor = valor;
        this.numerica=numerica;
        this.meeple = meeple;
        this.naveEspacial = naveEspacial;
        this.superheroe = superheroe;
        this.corazon = corazon;
        this.dragon = dragon;

    }

    public int getValor() {
        return valor;
    }



    public int meeple(Dado[] dadosActivos) {
        Random aleatorio = new Random();
        return aleatorio.nextInt(dadosActivos.length);

    }

    public int naveEspacial(Dado[] dadosActivos, Dado[] dadosInactivos) {
        Random aleatorio = new Random();
        int indice = aleatorio.nextInt(dadosActivos.length);
        Dado dadoEliminado = dadosActivos[indice];
        for (int i = indice; i < dadosActivos.length - 1; i++) {
            dadosActivos[i] = dadosActivos[i + 1];
        }
        dadosActivos[dadosActivos.length - 1] = null;
        for (int i = 0; i < dadosInactivos.length; i++) {
            if (dadosInactivos[i] == null) {
                dadosInactivos[i] = dadoEliminado;
                return indice;
            }
        }
        return -1;
    }

    public void superheroe(Dado[] dadosActivos, int indice) {
        Dado dado = dadosActivos[indice];
        dado.setCara(7 - dado.getCara());
    }

    public int corazon(Dado[] dadosInactivos) {
        for (int i = 0; i < dadosInactivos.length; i++) {
            if (dadosInactivos[i] == null) {
                return i;
            }
        }
        return -1;
    }

    public boolean dragon() {
        return dragon;
    }

    public boolean numerica(){
        return numerica;
    }


}


